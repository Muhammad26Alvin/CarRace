package carrace;

public interface Character {
    void move(double deltaX, double deltaY);
    void preventOutOfBounds();
    double getX();
    double getY();
}
